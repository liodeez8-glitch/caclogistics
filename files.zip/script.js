/**
 * Fast Trans Group — script.js
 * Handles: Navbar, Tracking form, Contact form, Animations
 */

'use strict';

/* ─────────────────────────────────────
   SHARED UTILITIES
───────────────────────────────────── */

/** Sanitise and trim a string value */
const sanitise = v => (v || '').trim();

/** Escape HTML entities to prevent XSS */
function escapeHtml(str) {
  const map = { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#x27;' };
  return String(str).replace(/[&<>"']/g, c => map[c]);
}

/** Retrieve a URL query param by name */
function getParam(name) {
  return new URLSearchParams(window.location.search).get(name) || '';
}

/* ─────────────────────────────────────
   NAVBAR — hamburger toggle + active link
───────────────────────────────────── */
function initNavbar() {
  const hamburger  = document.getElementById('hamburger');
  const mobileNav  = document.getElementById('mobileNav');
  if (!hamburger || !mobileNav) return;

  // Toggle mobile menu
  hamburger.addEventListener('click', () => {
    const isOpen = hamburger.classList.toggle('open');
    mobileNav.classList.toggle('open', isOpen);
    hamburger.setAttribute('aria-expanded', isOpen);
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  // Close on link click
  mobileNav.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileNav.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // Close on outside click
  document.addEventListener('click', e => {
    if (!hamburger.contains(e.target) && !mobileNav.contains(e.target)) {
      hamburger.classList.remove('open');
      mobileNav.classList.remove('open');
      document.body.style.overflow = '';
    }
  });

  // Mark active link based on current page
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav__links a, .nav__mobile a').forEach(a => {
    const href = a.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });
}

/* ─────────────────────────────────────
   TRACKING FORM — tracking.html
   Validates inputs, redirects to result page with query params
───────────────────────────────────── */
function initTrackingForm() {
  const form   = document.getElementById('trackingForm');
  if (!form) return;

  const numInput  = document.getElementById('trackingNumber');
  const modeInput = document.getElementById('transportMode');
  const numErr    = document.getElementById('numError');
  const modeErr   = document.getElementById('modeError');
  const submitBtn = document.getElementById('trackSubmit');
  const btnLabel  = submitBtn?.querySelector('.btn-label');
  const btnSpin   = submitBtn?.querySelector('.btn-spinner');
  const btnArrow  = submitBtn?.querySelector('.btn-arrow');

  // Live-clear errors on input
  numInput?.addEventListener('input',  () => clearErr(numInput, numErr));
  modeInput?.addEventListener('change', () => clearErr(modeInput, modeErr));

  form.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;

    // Validate tracking number
    const num = sanitise(numInput?.value);
    if (!num || num.length < 4) {
      showErr(numInput, numErr, 'Please enter a valid tracking number (min. 4 characters).');
      valid = false;
    } else clearErr(numInput, numErr);

    // Validate transport mode
    const mode = modeInput?.value;
    if (!mode) {
      showErr(modeInput, modeErr, 'Please select a transport mode.');
      valid = false;
    } else clearErr(modeInput, modeErr);

    if (!valid) return;

    // Show loading state
    setLoading(true, btnLabel, btnSpin, btnArrow, submitBtn);

    // Simulate brief lookup delay then redirect
    // BACKEND INTEGRATION: Replace setTimeout with real API call here.
    setTimeout(() => {
      const params = new URLSearchParams({ id: num, mode });
      window.location.href = `tracking-result.html?${params.toString()}`;
    }, 1200);
  });
}

/* ─────────────────────────────────────
   TRACKING RESULT — tracking-result.html
   Reads query params and renders shipment details + progress
───────────────────────────────────── */
function initTrackingResult() {
  const container = document.getElementById('resultContainer');
  if (!container) return;

  const trackingId = escapeHtml(getParam('id') || 'FTG-2024-00123');
  const mode       = getParam('mode') || 'air';

  /** Placeholder shipment data — replace with real API response */
  const modeLabels = { land: 'Land Shipping 🚛', air: 'Air Freight ✈️', sea: 'Sea Shipping 🚢' };
  const modeLabel  = modeLabels[mode] || 'Air Freight ✈️';

  const shipment = {
    id:        trackingId,
    type:      mode === 'sea' ? 'Ocean Freight (LCL)' : mode === 'land' ? 'Road Freight (FTL)' : 'Air Cargo (Express)',
    status:    'In Transit',
    statusKey: 'transit',     // 'processing' | 'transit' | 'delivered'
    origin:    'Dubai, UAE',
    dest:      'London, UK',
    shipped:   '2024-11-18',
    eta:       '2024-11-24',
    weight:    '142 kg',
    pieces:    '4 Packages',
    mode:      modeLabel,
  };

  // Progress step (1 = Processing, 2 = In Transit, 3 = Delivered)
  const progressMap = { processing: 1, transit: 2, delivered: 3 };
  const progress    = progressMap[shipment.statusKey] || 1;

  // Status badge HTML
  const statusBadgeClass = { transit: 'status-badge--transit', delivered: 'status-badge--delivered', processing: 'status-badge--processing' }[shipment.statusKey] || 'status-badge--processing';

  // Step states
  const stepState = step => {
    if (step < progress)  return 'progress-step--done';
    if (step === progress) return 'progress-step--active';
    return '';
  };

  // Checkmark icon
  const checkIcon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
  // Spinner icon
  const spinIcon  = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9" opacity="0.2"/><path d="M12 3a9 9 0 0 1 9 9" stroke-linecap="round"/></svg>`;

  // Render the full result block
  container.innerHTML = `
    <!-- Delivery message banner -->
    <div class="delivery-banner" role="status" aria-live="polite">
      <span class="delivery-banner__icon">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/>
        </svg>
      </span>
      <p class="delivery-banner__text">
        Your shipment <strong>${shipment.id}</strong> is currently
        <strong>${shipment.status}</strong>.
        Estimated delivery: <strong>${shipment.eta}</strong>.
        Our team is ensuring your cargo arrives safely and on time.
      </p>
    </div>

    <!-- Two-column detail cards -->
    <div class="result-layout">

      <!-- Shipment Info -->
      <div class="result-card">
        <div class="result-card__header">
          <span class="result-card__title">Shipment Details</span>
          <span class="status-badge ${statusBadgeClass}">
            <span class="status-dot"></span>
            ${shipment.status}
          </span>
        </div>
        <div class="result-card__body">
          <div class="result-row">
            <span class="result-row__key">Tracking ID</span>
            <span class="result-row__val" style="color:var(--red)">${shipment.id}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Package Type</span>
            <span class="result-row__val">${shipment.type}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Transport Mode</span>
            <span class="result-row__val">${shipment.mode}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Weight</span>
            <span class="result-row__val">${shipment.weight}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Pieces</span>
            <span class="result-row__val">${shipment.pieces}</span>
          </div>
        </div>
      </div>

      <!-- Route Info -->
      <div class="result-card">
        <div class="result-card__header">
          <span class="result-card__title">Route Information</span>
        </div>
        <div class="result-card__body">
          <div class="result-row">
            <span class="result-row__key">Origin</span>
            <span class="result-row__val">${shipment.origin}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Destination</span>
            <span class="result-row__val">${shipment.dest}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Shipment Date</span>
            <span class="result-row__val">${formatDate(shipment.shipped)}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Est. Delivery</span>
            <span class="result-row__val" style="color:var(--gold)">${formatDate(shipment.eta)}</span>
          </div>
          <div class="result-row">
            <span class="result-row__key">Status</span>
            <span class="result-row__val">${shipment.status}</span>
          </div>
        </div>
      </div>

    </div>
    <!-- /result-layout -->

    <!-- Progress tracker -->
    <div class="progress-tracker" role="region" aria-label="Shipment progress">
      <p class="progress-tracker__heading">Shipment Progress</p>
      <div class="progress-steps" data-progress="${progress}" role="list">

        <!-- Step 1: Processing -->
        <div class="progress-step ${stepState(1)}" role="listitem">
          <div class="progress-step__icon-wrap" aria-label="${progress >= 1 ? 'Complete' : 'Pending'}">
            ${progress > 1 ? checkIcon : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l2 2"/></svg>`}
          </div>
          <div>
            <div class="progress-step__label">Processing</div>
            <div class="progress-step__date">Nov 18, 2024</div>
          </div>
        </div>

        <!-- Step 2: In Transit -->
        <div class="progress-step ${stepState(2)}" role="listitem">
          <div class="progress-step__icon-wrap" aria-label="${progress >= 2 ? 'Active' : 'Pending'}">
            ${progress > 2
              ? checkIcon
              : progress === 2
                ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 3v5h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`
                : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 3v5h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`
            }
          </div>
          <div>
            <div class="progress-step__label">In Transit</div>
            <div class="progress-step__date">Nov 20, 2024</div>
          </div>
        </div>

        <!-- Step 3: Delivered -->
        <div class="progress-step ${stepState(3)}" role="listitem">
          <div class="progress-step__icon-wrap" aria-label="${progress >= 3 ? 'Delivered' : 'Pending'}">
            ${progress >= 3
              ? checkIcon
              : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 12V22H4V12"/><path d="M22 7H2v5h20V7z"/><path d="M12 22V7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>`
            }
          </div>
          <div>
            <div class="progress-step__label">Delivered</div>
            <div class="progress-step__date">${shipment.eta}</div>
          </div>
        </div>

      </div>
    </div>
    <!-- /progress-tracker -->

    <!-- Back button -->
    <div style="text-align:center">
      <a href="tracking.html" class="btn btn-ghost-red">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
        Track Another Shipment
      </a>
    </div>
  `;
}

/** Format ISO date string to human-readable */
function formatDate(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch { return iso; }
}

/* ─────────────────────────────────────
   CONTACT FORM — contact.html
───────────────────────────────────── */
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const btn     = form.querySelector('button[type="submit"]');
    const success = document.getElementById('formSuccess');

    // Basic required field validation
    let valid = true;
    form.querySelectorAll('[required]').forEach(field => {
      if (!sanitise(field.value)) {
        field.classList.add('form-input--err');
        valid = false;
      } else {
        field.classList.remove('form-input--err');
      }
    });
    if (!valid) return;

    // Simulate submission
    // BACKEND INTEGRATION: Replace with real fetch('/api/contact', {...}) call
    btn.disabled = true;
    btn.textContent = 'Sending…';
    setTimeout(() => {
      btn.disabled = false;
      btn.textContent = 'Send Message';
      form.reset();
      if (success) {
        success.removeAttribute('hidden');
        setTimeout(() => success.setAttribute('hidden', ''), 6000);
      }
    }, 1400);
  });
}

/* ─────────────────────────────────────
   FORM HELPERS
───────────────────────────────────── */
function showErr(field, errEl, msg) {
  field?.classList.add('form-input--err', 'form-select--err');
  field?.setAttribute('aria-invalid', 'true');
  if (errEl) { errEl.textContent = msg; errEl.removeAttribute('hidden'); }
}
function clearErr(field, errEl) {
  field?.classList.remove('form-input--err', 'form-select--err');
  field?.removeAttribute('aria-invalid');
  errEl?.setAttribute('hidden', '');
}
function setLoading(loading, label, spinner, arrow, btn) {
  if (!btn) return;
  btn.disabled = loading;
  if (label)  label.textContent = loading ? 'Searching…' : 'Track Shipment';
  if (spinner) loading ? spinner.removeAttribute('hidden') : spinner.setAttribute('hidden','');
  if (arrow)   loading ? arrow.setAttribute('hidden','') : arrow.removeAttribute('hidden');
}

/* ─────────────────────────────────────
   SCROLL ANIMATIONS
   Fade-in elements as they enter viewport
───────────────────────────────────── */
function initScrollAnimations() {
  const els = document.querySelectorAll('.svc-card, .why-card, .testi-card, .team-card, .stat-block, .track-info-block, .contact-block, .result-card, .value-item');
  if (!('IntersectionObserver' in window)) return;

  const observer = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        entry.target.style.animationDelay = `${i * 0.06}s`;
        entry.target.classList.add('animate-in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  els.forEach(el => {
    el.style.opacity = '0';
    observer.observe(el);
  });
}

/* ─────────────────────────────────────
   COUNTER ANIMATION (stats)
───────────────────────────────────── */
function initCounters() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length || !('IntersectionObserver' in window)) return;

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el     = entry.target;
      const target = parseInt(el.dataset.count, 10);
      const suffix = el.dataset.suffix || '';
      const duration = 1600;
      const start  = performance.now();
      const tick   = now => {
        const progress = Math.min((now - start) / duration, 1);
        const eased    = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(eased * target) + suffix;
        if (progress < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));
}

/* ─────────────────────────────────────
   INIT
───────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initTrackingForm();
  initTrackingResult();
  initContactForm();
  initScrollAnimations();
  initCounters();
});
